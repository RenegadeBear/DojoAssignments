package com.rnc.skillsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillsdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillsdemoApplication.class, args);
	}
}
