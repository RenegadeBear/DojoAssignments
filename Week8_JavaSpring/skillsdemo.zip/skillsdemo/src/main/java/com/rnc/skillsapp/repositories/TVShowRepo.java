package com.rnc.skillsapp.repositories;



import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.rnc.skillsapp.models.TVShow;

@Repository
public interface TVShowRepo extends CrudRepository<TVShow, Long> {

	
}
